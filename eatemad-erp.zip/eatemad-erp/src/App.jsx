import { useState, useEffect, createContext, useContext } from "react"
import {
  Users, Building2, Archive, Search, LogOut, Globe,
  Eye, EyeOff, Loader2, AlertTriangle, Menu, Home,
  ShoppingCart, MessageSquare, BarChart2, Settings,
  ChevronLeft, ChevronRight, UserCheck, RefreshCw
} from "lucide-react"

// ═══════════════════════════════════════════════════════════
// CONFIG — Supabase
// ═══════════════════════════════════════════════════════════
const SB = "https://fmajfprdlczvfudhwbcj.supabase.co"
const KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZtYWpmcHJkbGN6dmZ1ZGh3YmNqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzI1NTk2NDQsImV4cCI6MjA4ODEzNTY0NH0.EjCDKzsZvbT31mbaBhoW4DfZtVj0rNc1U3w_goSouaU"

// ═══════════════════════════════════════════════════════════
// SUPABASE HELPERS
// ═══════════════════════════════════════════════════════════
const api = {
  headers: (token) => ({
    "apikey": KEY,
    "Content-Type": "application/json",
    ...(token && { "Authorization": `Bearer ${token}` })
  }),
  async signIn(email, password) {
    const r = await fetch(`${SB}/auth/v1/token?grant_type=password`, {
      method: "POST", headers: api.headers(null),
      body: JSON.stringify({ email, password })
    })
    return r.json()
  },
  async signOut(token) {
    await fetch(`${SB}/auth/v1/logout`, { method: "POST", headers: api.headers(token) })
  },
  async profile(uid, token) {
    const r = await fetch(`${SB}/rest/v1/profiles?id=eq.${uid}&select=*`, { headers: api.headers(token) })
    const d = await r.json(); return d[0] || null
  },
  async employees(token, qs = "") {
    const r = await fetch(`${SB}/rest/v1/employees_view?select=*&order=sn${qs}`, { headers: api.headers(token) })
    return r.json()
  },
  async count(table, token) {
    const r = await fetch(`${SB}/rest/v1/${table}?select=id&limit=1`, {
      headers: { ...api.headers(token), "Prefer": "count=exact" }
    })
    return parseInt(r.headers.get("content-range")?.split("/")?.[1] || "0")
  }
}

// ═══════════════════════════════════════════════════════════
// DESIGN TOKENS
// ═══════════════════════════════════════════════════════════
const C = {
  bg:       "#080b13",
  surface:  "#0f1420",
  surface2: "#161d2e",
  border:   "#1e2840",
  borderHi: "#2a3a58",
  gold:     "#c49a3c",
  goldLt:   "#ddb85a",
  goldBg:   "rgba(196,154,60,0.12)",
  text:     "#dde4f0",
  muted:    "#5a6a8a",
  blue:     "#4a90d9",
  green:    "#2ecc8a",
  orange:   "#e8923a",
  red:      "#e05555",
  purple:   "#9b7fe8",
}

// ═══════════════════════════════════════════════════════════
// I18N
// ═══════════════════════════════════════════════════════════
const T = {
  en: {
    appName:"Al Eatemad", tagline:"Business Management System",
    signIn:"Sign In", email:"Email Address", password:"Password",
    loginBtn:"Sign In", loginErr:"Invalid email or password",
    dashboard:"Dashboard", hr:"Human Resources", branches:"Branches",
    customers:"Customers", b2b:"B2B", crm:"CRM", reports:"Reports",
    settings:"Settings", logout:"Sign Out",
    totalEmp:"Total Employees", archived:"Archived Employees",
    totalCust:"Customers", activeBr:"Active Branches",
    search:"Search by name, title, nationality…",
    allBranches:"All Branches", allStatus:"All Status",
    sn:"#", name:"Name", title:"Job Title", branch:"Branch",
    nat:"Nationality", status:"Status", startDate:"Start Date",
    salary:"Salary", loading:"Loading…", noEmp:"No employees found",
    comingSoon:"Coming Soon", comingDesc:"This module is under development",
    greetAm:"Good morning", greetPm:"Good afternoon",
    phase:"Phase 1 · Alpha",
    r_admin:"Administrator", r_manager:"Manager",
    r_hr_manager:"HR Manager", r_agent:"Agent", r_viewer:"Viewer",
    modules:"System Modules", quickNav:"Quick Navigation",
    of:"of", rows:"rows",
  },
  ar: {
    appName:"الاعتماد", tagline:"نظام إدارة الأعمال",
    signIn:"تسجيل الدخول", email:"البريد الإلكتروني", password:"كلمة المرور",
    loginBtn:"دخول", loginErr:"البريد أو كلمة المرور غير صحيحة",
    dashboard:"الرئيسية", hr:"الموارد البشرية", branches:"الفروع",
    customers:"العملاء", b2b:"B2B", crm:"CRM", reports:"التقارير",
    settings:"الإعدادات", logout:"تسجيل الخروج",
    totalEmp:"الموظفون النشطون", archived:"المنتهية خدمتهم",
    totalCust:"العملاء", activeBr:"الفروع",
    search:"بحث بالاسم أو المسمى الوظيفي…",
    allBranches:"جميع الفروع", allStatus:"جميع الحالات",
    sn:"م", name:"الاسم", title:"المسمى الوظيفي", branch:"الفرع",
    nat:"الجنسية", status:"الحالة", startDate:"تاريخ البدء",
    salary:"الراتب الإجمالي", loading:"جاري التحميل…", noEmp:"لا يوجد موظفون",
    comingSoon:"قريباً", comingDesc:"هذه الوحدة قيد التطوير",
    greetAm:"صباح الخير", greetPm:"مساء الخير",
    phase:"المرحلة الأولى",
    r_admin:"مسؤول النظام", r_manager:"مدير", r_hr_manager:"مدير الموارد البشرية",
    r_agent:"موظف", r_viewer:"مشاهد",
    modules:"وحدات النظام", quickNav:"الوصول السريع",
    of:"من", rows:"سجل",
  }
}

// ═══════════════════════════════════════════════════════════
// AUTH CONTEXT
// ═══════════════════════════════════════════════════════════
const Ctx = createContext(null)
const useAuth = () => useContext(Ctx)

function AuthProvider({ children }) {
  const [session, setSession] = useState(null)
  const [profile, setProfile] = useState(null)
  const [busy, setBusy] = useState(false)

  const login = async (email, password) => {
    setBusy(true)
    try {
      const d = await api.signIn(email, password)
      if (d.error || !d.access_token) return { error: true }
      const prof = await api.profile(d.user.id, d.access_token)
      setSession(d); setProfile(prof)
      return { ok: true }
    } catch { return { error: true } }
    finally { setBusy(false) }
  }

  const logout = async () => {
    if (session?.access_token) await api.signOut(session.access_token)
    setSession(null); setProfile(null)
  }

  return (
    <Ctx.Provider value={{ session, profile, busy, login, logout, token: session?.access_token }}>
      {children}
    </Ctx.Provider>
  )
}

// ═══════════════════════════════════════════════════════════
// LOGIN
// ═══════════════════════════════════════════════════════════
function Login({ lang, setLang }) {
  const { login, busy } = useAuth()
  const t = T[lang]
  const [email, setEmail] = useState("")
  const [pass, setPass] = useState("")
  const [show, setShow] = useState(false)
  const [err, setErr] = useState(false)

  const submit = async (e) => {
    e.preventDefault(); setErr(false)
    const r = await login(email, pass)
    if (!r.ok) setErr(true)
  }

  const isAr = lang === "ar"

  return (
    <div style={{
      minHeight:"100vh", background: C.bg, display:"flex", alignItems:"center",
      justifyContent:"center", direction: isAr ? "rtl":"ltr",
      fontFamily: isAr ? "Tajawal,sans-serif":"DM Sans,sans-serif",
      position:"relative", overflow:"hidden"
    }}>
      {/* glow */}
      <div style={{
        position:"absolute", top:"-15%", right: isAr?"auto":"-5%", left: isAr?"-5%":"auto",
        width:700, height:700, borderRadius:"50%", pointerEvents:"none",
        background:`radial-gradient(circle, ${C.goldBg} 0%, transparent 65%)`
      }}/>
      <div style={{
        position:"absolute", bottom:"-20%", left: isAr?"auto":"5%", right: isAr?"5%":"auto",
        width:500, height:500, borderRadius:"50%", pointerEvents:"none",
        background:`radial-gradient(circle, rgba(74,144,217,0.06) 0%, transparent 65%)`
      }}/>

      {/* lang pill */}
      <button onClick={() => setLang(isAr?"en":"ar")} style={{
        position:"absolute", top:24, [isAr?"left":"right"]:24,
        background:C.surface, border:`1px solid ${C.border}`, color:C.text,
        borderRadius:24, padding:"7px 16px", cursor:"pointer",
        display:"flex", alignItems:"center", gap:8, fontSize:13, fontFamily:"inherit"
      }}>
        <Globe size={14} color={C.gold}/>
        {isAr?"English":"عربي"}
      </button>

      <div style={{ width:"100%", maxWidth:400, padding:"0 24px" }}>
        {/* brand */}
        <div style={{ textAlign:"center", marginBottom:36 }}>
          <div style={{
            display:"inline-flex", alignItems:"center", justifyContent:"center",
            width:68, height:68, borderRadius:20, marginBottom:18,
            background:`linear-gradient(145deg, ${C.gold}, ${C.goldLt})`,
            boxShadow:`0 12px 40px rgba(196,154,60,0.35), 0 4px 12px rgba(0,0,0,0.4)`
          }}>
            <span style={{fontSize:32}}>🥩</span>
          </div>
          <h1 style={{ color:C.text, fontSize:26, fontWeight:700, margin:0, letterSpacing: isAr?0:-0.5 }}>
            {isAr ? "ملحمة ومشاوي الاعتماد" : "Al Eatemad ERP"}
          </h1>
          <p style={{ color:C.muted, fontSize:13, marginTop:6, marginBottom:0 }}>{t.tagline}</p>
        </div>

        {/* card */}
        <div style={{
          background:C.surface, border:`1px solid ${C.border}`,
          borderRadius:18, padding:32,
          boxShadow:"0 32px 80px rgba(0,0,0,0.5), 0 0 0 1px rgba(255,255,255,0.03)"
        }}>
          <h2 style={{ color:C.text, fontSize:19, fontWeight:600, margin:"0 0 24px" }}>{t.signIn}</h2>

          <form onSubmit={submit}>
            <div style={{ marginBottom:14 }}>
              <label style={{ color:C.muted, fontSize:12, display:"block", marginBottom:7, fontWeight:500 }}>
                {t.email}
              </label>
              <input type="email" value={email} onChange={e=>setEmail(e.target.value)} required
                style={{
                  width:"100%", background:C.bg, border:`1.5px solid ${C.border}`,
                  borderRadius:9, padding:"11px 14px", color:C.text, fontSize:14,
                  fontFamily:"inherit", outline:"none", boxSizing:"border-box", transition:"border-color .15s"
                }}
                onFocus={e=>e.target.style.borderColor=C.gold}
                onBlur={e=>e.target.style.borderColor=C.border}
              />
            </div>

            <div style={{ marginBottom:22 }}>
              <label style={{ color:C.muted, fontSize:12, display:"block", marginBottom:7, fontWeight:500 }}>
                {t.password}
              </label>
              <div style={{ position:"relative" }}>
                <input type={show?"text":"password"} value={pass} onChange={e=>setPass(e.target.value)} required
                  style={{
                    width:"100%", background:C.bg, border:`1.5px solid ${C.border}`,
                    borderRadius:9, padding:`11px ${isAr?14:42}px 11px ${isAr?42:14}px`,
                    color:C.text, fontSize:14, fontFamily:"inherit", outline:"none",
                    boxSizing:"border-box", transition:"border-color .15s"
                  }}
                  onFocus={e=>e.target.style.borderColor=C.gold}
                  onBlur={e=>e.target.style.borderColor=C.border}
                />
                <button type="button" onClick={()=>setShow(!show)} style={{
                  position:"absolute", top:"50%", transform:"translateY(-50%)",
                  [isAr?"left":"right"]:12,
                  background:"none", border:"none", cursor:"pointer", padding:4, lineHeight:0
                }}>
                  {show ? <EyeOff size={16} color={C.muted}/> : <Eye size={16} color={C.muted}/>}
                </button>
              </div>
            </div>

            {err && (
              <div style={{
                display:"flex", alignItems:"center", gap:8, marginBottom:16,
                background:"rgba(224,85,85,0.08)", border:"1px solid rgba(224,85,85,0.25)",
                borderRadius:8, padding:"10px 14px", color:"#f08080", fontSize:13
              }}>
                <AlertTriangle size={15}/> {t.loginErr}
              </div>
            )}

            <button type="submit" disabled={busy} style={{
              width:"100%", border:"none", borderRadius:9, padding:"12px 24px",
              background: busy ? C.muted : `linear-gradient(135deg, ${C.gold}, ${C.goldLt})`,
              color:"#0a0b10", fontSize:15, fontWeight:700, cursor: busy?"not-allowed":"pointer",
              fontFamily:"inherit", display:"flex", alignItems:"center", justifyContent:"center",
              gap:8, boxShadow: busy?"none":`0 6px 20px rgba(196,154,60,0.35)`,
              transition:"opacity .15s"
            }}>
              {busy && <Loader2 size={17} style={{animation:"spin 1s linear infinite"}}/>}
              {busy ? t.loading : t.loginBtn}
            </button>
          </form>
        </div>

        <p style={{ textAlign:"center", color:C.muted, fontSize:11, marginTop:20 }}>
          {t.phase}
        </p>
      </div>

      <style>{`
        @keyframes spin { to { transform:rotate(360deg) } }
        @keyframes fadeUp { from { opacity:0; transform:translateY(10px) } to { opacity:1; transform:none } }
        * { box-sizing:border-box }
        ::-webkit-scrollbar { width:5px; height:5px }
        ::-webkit-scrollbar-track { background:${C.bg} }
        ::-webkit-scrollbar-thumb { background:${C.border}; border-radius:3px }
        select option { background:${C.surface2}; color:${C.text} }
      `}</style>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════
// SIDEBAR
// ═══════════════════════════════════════════════════════════
function Sidebar({ lang, page, setPage, collapsed }) {
  const { logout, profile } = useAuth()
  const t = T[lang], isAr = lang==="ar"

  const nav = [
    { id:"dashboard", Icon:Home,       label:t.dashboard  },
    { id:"hr",        Icon:Users,       label:t.hr         },
    { id:"branches",  Icon:Building2,   label:t.branches   },
    { id:"customers", Icon:ShoppingCart,label:t.customers  },
    { id:"b2b",       Icon:UserCheck,   label:t.b2b        },
    { id:"crm",       Icon:MessageSquare,label:t.crm       },
    { id:"reports",   Icon:BarChart2,   label:t.reports    },
    { id:"settings",  Icon:Settings,    label:t.settings   },
  ]

  const roleLabel = profile ? (t[`r_${profile.role}`] || profile.role) : ""

  return (
    <div style={{
      width: collapsed ? 62 : 230, height:"100vh", background:C.surface,
      borderRight: isAr ? "none":"1px solid "+C.border,
      borderLeft:  isAr ? "1px solid "+C.border:"none",
      display:"flex", flexDirection:"column", flexShrink:0,
      transition:"width .2s ease", overflow:"hidden"
    }}>
      {/* Logo row */}
      <div style={{
        height:68, display:"flex", alignItems:"center",
        padding: collapsed?"0":"0 18px",
        justifyContent: collapsed?"center":"flex-start",
        gap:11, borderBottom:`1px solid ${C.border}`, flexShrink:0
      }}>
        <div style={{
          width:38, height:38, borderRadius:11, flexShrink:0,
          background:`linear-gradient(145deg, ${C.gold}, ${C.goldLt})`,
          display:"flex", alignItems:"center", justifyContent:"center",
          fontSize:19, boxShadow:`0 4px 14px rgba(196,154,60,0.3)`
        }}>🥩</div>
        {!collapsed && (
          <div>
            <div style={{ color:C.text, fontWeight:700, fontSize:13, lineHeight:1.2 }}>
              {isAr?"الاعتماد":"Al Eatemad"}
            </div>
            <div style={{ color:C.gold, fontSize:10, marginTop:3, letterSpacing:0.5 }}>ERP SYSTEM</div>
          </div>
        )}
      </div>

      {/* Nav items */}
      <nav style={{ flex:1, padding:"10px 0", overflowY:"auto" }}>
        {nav.map(({ id, Icon, label }) => {
          const active = page === id
          return (
            <button key={id} onClick={()=>setPage(id)} style={{
              width:"100%", display:"flex", alignItems:"center",
              gap:11, padding: collapsed?"12px 0":"10px 18px",
              justifyContent: collapsed?"center":"flex-start",
              background: active ? C.goldBg : "transparent",
              border:"none", cursor:"pointer", fontFamily:"inherit",
              color: active ? C.gold : C.muted, fontSize:13.5,
              fontWeight: active ? 600 : 400, transition:"all .12s",
              position:"relative"
            }}
            onMouseEnter={e=>{ if(!active) e.currentTarget.style.background="rgba(255,255,255,0.025)" }}
            onMouseLeave={e=>{ if(!active) e.currentTarget.style.background="transparent" }}
            >
              {active && <div style={{
                position:"absolute", [isAr?"right":"left"]:0,
                top:0, bottom:0, width:3, background:C.gold,
                borderRadius: isAr?"3px 0 0 3px":"0 3px 3px 0"
              }}/>}
              <Icon size={17}/>
              {!collapsed && <span>{label}</span>}
            </button>
          )
        })}
      </nav>

      {/* User card */}
      <div style={{ padding: collapsed?"10px 0":"14px", borderTop:`1px solid ${C.border}`, flexShrink:0 }}>
        {!collapsed && profile && (
          <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:12 }}>
            <div style={{
              width:36, height:36, borderRadius:"50%", flexShrink:0,
              background:C.goldBg, border:`1.5px solid ${C.gold}`,
              display:"flex", alignItems:"center", justifyContent:"center",
              color:C.gold, fontWeight:700, fontSize:15
            }}>
              {(profile.full_name||profile.email||"U")[0].toUpperCase()}
            </div>
            <div style={{ overflow:"hidden" }}>
              <div style={{ color:C.text, fontSize:12.5, fontWeight:600, whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>
                {profile.full_name || profile.email}
              </div>
              <div style={{ color:C.gold, fontSize:11, marginTop:2 }}>{roleLabel}</div>
            </div>
          </div>
        )}
        <button onClick={logout} style={{
          width:"100%", display:"flex", alignItems:"center", justifyContent:"center",
          gap:8, padding:"8px 10px",
          background:"rgba(224,85,85,0.07)", border:"1px solid rgba(224,85,85,0.18)",
          borderRadius:8, color:"#e08080", fontSize:12.5, cursor:"pointer", fontFamily:"inherit"
        }}>
          <LogOut size={14}/>
          {!collapsed && t.logout}
        </button>
      </div>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════
// HEADER
// ═══════════════════════════════════════════════════════════
function Header({ lang, setLang, collapsed, setCollapsed, title }) {
  const { profile } = useAuth()
  const t = T[lang], isAr = lang==="ar"
  const h = new Date().getHours()
  const greet = h < 13 ? t.greetAm : t.greetPm

  return (
    <div style={{
      height:68, background:C.surface, borderBottom:`1px solid ${C.border}`,
      display:"flex", alignItems:"center", padding:"0 22px", gap:14, flexShrink:0
    }}>
      <button onClick={()=>setCollapsed(!collapsed)} style={{
        background:"none", border:"none", cursor:"pointer",
        padding:7, color:C.muted, borderRadius:7, display:"flex", lineHeight:0
      }}>
        <Menu size={20}/>
      </button>

      <div style={{ flex:1 }}>
        <div style={{ color:C.text, fontWeight:700, fontSize:17, lineHeight:1.2 }}>{title}</div>
        {profile && (
          <div style={{ color:C.muted, fontSize:11.5, marginTop:2 }}>
            {greet}، {profile.full_name || profile.email}
          </div>
        )}
      </div>

      <button onClick={()=>setLang(isAr?"en":"ar")} style={{
        display:"flex", alignItems:"center", gap:7, padding:"7px 13px",
        background:C.surface2, border:`1px solid ${C.border}`, borderRadius:8,
        color:C.text, fontSize:12.5, cursor:"pointer", fontFamily:"inherit"
      }}>
        <Globe size={13} color={C.gold}/>
        {isAr?"EN":"عربي"}
      </button>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════
// STAT CARD
// ═══════════════════════════════════════════════════════════
function Stat({ icon:Icon, label, value, color, loading }) {
  return (
    <div style={{
      background:C.surface, border:`1px solid ${C.border}`, borderRadius:14,
      padding:"18px 20px", display:"flex", alignItems:"center", gap:16,
      animation:"fadeUp .3s ease"
    }}>
      <div style={{
        width:50, height:50, borderRadius:13, flexShrink:0,
        background:`${color}18`, display:"flex", alignItems:"center", justifyContent:"center"
      }}>
        <Icon size={22} color={color}/>
      </div>
      <div>
        <div style={{ color:C.muted, fontSize:12, marginBottom:5, fontWeight:500 }}>{label}</div>
        <div style={{ color:C.text, fontSize:28, fontWeight:700, lineHeight:1 }}>
          {loading
            ? <Loader2 size={20} color={C.muted} style={{animation:"spin 1s linear infinite"}}/>
            : value?.toLocaleString() ?? "—"}
        </div>
      </div>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════
// DASHBOARD PAGE
// ═══════════════════════════════════════════════════════════
function Dashboard({ lang }) {
  const { token } = useAuth()
  const t = T[lang]
  const [stats, setStats] = useState({})
  const [busy, setBusy] = useState(true)

  const load = async () => {
    setBusy(true)
    try {
      const [emp, arch, cust, br] = await Promise.all([
        api.count("employees", token),
        api.count("archived_employees", token),
        api.count("customers", token),
        api.count("branches", token),
      ])
      setStats({ emp, arch, cust, br })
    } catch {} finally { setBusy(false) }
  }

  useEffect(() => { load() }, [token])

  const quickItems = [
    { label:t.hr,        icon:"👥", color:C.blue   },
    { label:t.customers, icon:"🛒", color:C.green  },
    { label:t.b2b,       icon:"🤝", color:C.gold   },
    { label:t.crm,       icon:"💬", color:C.purple },
    { label:t.reports,   icon:"📊", color:C.orange },
    { label:t.settings,  icon:"⚙️", color:C.muted  },
  ]

  return (
    <div style={{ padding:26 }}>
      {/* Stat row */}
      <div style={{
        display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(210px,1fr))",
        gap:14, marginBottom:24
      }}>
        <Stat icon={Users}     label={t.totalEmp}  value={stats.emp}  color={C.blue}   loading={busy}/>
        <Stat icon={Archive}   label={t.archived}  value={stats.arch} color={C.orange} loading={busy}/>
        <Stat icon={ShoppingCart} label={t.totalCust} value={stats.cust} color={C.green} loading={busy}/>
        <Stat icon={Building2} label={t.activeBr}  value={stats.br}   color={C.gold}   loading={busy}/>
      </div>

      {/* Quick nav */}
      <div style={{
        background:C.surface, border:`1px solid ${C.border}`,
        borderRadius:14, padding:"18px 20px"
      }}>
        <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:16 }}>
          <h3 style={{ color:C.text, margin:0, fontSize:14, fontWeight:700 }}>{t.modules}</h3>
          <button onClick={load} style={{
            background:"none", border:"none", cursor:"pointer", padding:6, color:C.muted, lineHeight:0
          }}>
            <RefreshCw size={14}/>
          </button>
        </div>
        <div style={{
          display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(150px,1fr))", gap:10
        }}>
          {quickItems.map(({ label, icon, color }) => (
            <div key={label} style={{
              background:C.surface2, border:`1px solid ${C.border}`, borderRadius:10,
              padding:"13px 15px", display:"flex", alignItems:"center", gap:10,
              cursor:"pointer", transition:"border-color .12s"
            }}
            onMouseEnter={e=>e.currentTarget.style.borderColor=color}
            onMouseLeave={e=>e.currentTarget.style.borderColor=C.border}
            >
              <span style={{fontSize:20}}>{icon}</span>
              <span style={{ color:C.text, fontSize:13, fontWeight:500 }}>{label}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════
// HR PAGE
// ═══════════════════════════════════════════════════════════
function HR({ lang }) {
  const { token, profile } = useAuth()
  const t = T[lang], isAr = lang==="ar"
  const [rows, setRows] = useState([])
  const [busy, setBusy] = useState(true)
  const [q, setQ] = useState("")
  const [branchF, setBranchF] = useState("")
  const [pg, setPg] = useState(0)
  const PER = 15
  const canSalary = ["admin","hr_manager"].includes(profile?.role)

  const load = async () => {
    setBusy(true)
    try {
      const d = await api.employees(token)
      if (Array.isArray(d)) setRows(d)
    } catch {} finally { setBusy(false) }
  }

  useEffect(() => { load() }, [token])

  const branches = [...new Set(rows.map(r=>r.branch_name).filter(Boolean))]

  const filtered = rows.filter(r => {
    const s = q.toLowerCase()
    const matchQ = !s || [r.full_name,r.job_title,r.nationality].some(v=>v?.toLowerCase().includes(s))
    const matchB = !branchF || r.branch_name === branchF
    return matchQ && matchB
  })

  const total = filtered.length
  const pages = Math.ceil(total / PER)
  const slice = filtered.slice(pg*PER, (pg+1)*PER)

  const statusColor = (s="") => {
    if (s.includes("نشط") && !s.includes("مؤقت")) return C.green
    if (s.includes("قيد")) return C.orange
    if (s.includes("مؤقت")) return C.blue
    return C.muted
  }

  const cols = [t.sn, t.name, t.title, t.branch, t.nat, t.status, t.startDate, ...(canSalary?[t.salary]:[]) ]

  return (
    <div style={{ padding:26 }}>
      {/* Toolbar */}
      <div style={{ display:"flex", gap:10, marginBottom:18, flexWrap:"wrap", alignItems:"center" }}>
        <div style={{ position:"relative", flex:"1 1 260px" }}>
          <Search size={15} style={{
            position:"absolute", top:"50%", transform:"translateY(-50%)",
            [isAr?"right":"left"]:12, color:C.muted, pointerEvents:"none"
          }}/>
          <input value={q} onChange={e=>{setQ(e.target.value);setPg(0)}}
            placeholder={t.search}
            style={{
              width:"100%", background:C.surface, border:`1.5px solid ${C.border}`,
              borderRadius:8, padding:`10px ${isAr?14:40}px 10px ${isAr?40:14}px`,
              color:C.text, fontSize:13.5, fontFamily:"inherit", outline:"none"
            }}
            onFocus={e=>e.target.style.borderColor=C.gold}
            onBlur={e=>e.target.style.borderColor=C.border}
          />
        </div>

        <select value={branchF} onChange={e=>{setBranchF(e.target.value);setPg(0)}} style={{
          background:C.surface, border:`1.5px solid ${C.border}`, borderRadius:8,
          padding:"10px 14px", color:C.text, fontSize:13.5, fontFamily:"inherit",
          outline:"none", cursor:"pointer"
        }}>
          <option value="">{t.allBranches}</option>
          {branches.map(b=><option key={b} value={b}>{b}</option>)}
        </select>

        <button onClick={load} style={{
          background:C.surface, border:`1.5px solid ${C.border}`, borderRadius:8,
          padding:"10px 12px", cursor:"pointer", color:C.muted, lineHeight:0
        }}>
          <RefreshCw size={15}/>
        </button>

        <div style={{
          background:C.goldBg, border:`1px solid ${C.gold}30`, borderRadius:8,
          padding:"10px 16px", color:C.gold, fontSize:13, fontWeight:700,
          marginInlineStart:"auto"
        }}>
          {total.toLocaleString()} {isAr?"موظف":"employees"}
        </div>
      </div>

      {/* Table */}
      <div style={{
        background:C.surface, border:`1px solid ${C.border}`,
        borderRadius:13, overflow:"hidden"
      }}>
        <div style={{ overflowX:"auto" }}>
          <table style={{ width:"100%", borderCollapse:"collapse" }}>
            <thead>
              <tr style={{ background:C.surface2 }}>
                {cols.map(h=>(
                  <th key={h} style={{
                    padding:"11px 15px", color:C.muted, fontSize:11, fontWeight:700,
                    textAlign: isAr?"right":"left", whiteSpace:"nowrap",
                    borderBottom:`1px solid ${C.border}`, letterSpacing:0.6,
                    textTransform:"uppercase"
                  }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {busy ? (
                <tr><td colSpan={cols.length} style={{padding:52,textAlign:"center"}}>
                  <Loader2 size={26} color={C.gold} style={{animation:"spin 1s linear infinite"}}/>
                </td></tr>
              ) : slice.length===0 ? (
                <tr><td colSpan={cols.length} style={{padding:52,textAlign:"center",color:C.muted,fontSize:14}}>
                  {t.noEmp}
                </td></tr>
              ) : slice.map(e=>(
                <tr key={e.id} style={{ borderBottom:`1px solid ${C.border}`, transition:"background .1s" }}
                  onMouseEnter={ev=>ev.currentTarget.style.background=C.surface2}
                  onMouseLeave={ev=>ev.currentTarget.style.background="transparent"}
                >
                  <td style={{padding:"11px 15px",color:C.muted,fontSize:12}}>{e.sn}</td>
                  <td style={{padding:"11px 15px"}}>
                    <div style={{color:C.text,fontSize:13.5,fontWeight:600}}>{e.full_name}</div>
                    <div style={{color:C.muted,fontSize:11,marginTop:2}}>{e.company_name}</div>
                  </td>
                  <td style={{padding:"11px 15px",color:C.text,fontSize:13}}>{e.job_title}</td>
                  <td style={{padding:"11px 15px"}}>
                    <span style={{
                      background:`${C.blue}18`,color:C.blue,
                      borderRadius:6,padding:"3px 10px",fontSize:11.5,whiteSpace:"nowrap"
                    }}>{e.branch_name}</span>
                  </td>
                  <td style={{padding:"11px 15px",color:C.text,fontSize:13}}>{e.nationality}</td>
                  <td style={{padding:"11px 15px"}}>
                    <span style={{
                      background:`${statusColor(e.residence_status)}18`,
                      color:statusColor(e.residence_status),
                      borderRadius:6,padding:"3px 10px",fontSize:11.5
                    }}>{e.residence_status||"—"}</span>
                  </td>
                  <td style={{padding:"11px 15px",color:C.muted,fontSize:12,direction:"ltr",textAlign:isAr?"right":"left"}}>
                    {e.start_date ? new Date(e.start_date).toLocaleDateString("en-GB") : "—"}
                  </td>
                  {canSalary && (
                    <td style={{padding:"11px 15px",color:C.gold,fontSize:13,fontWeight:700,direction:"ltr",textAlign:isAr?"right":"left"}}>
                      {e.total_salary ? `${Number(e.total_salary).toLocaleString()} د.إ` : "—"}
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {pages > 1 && (
          <div style={{
            padding:"11px 16px", borderTop:`1px solid ${C.border}`,
            display:"flex", alignItems:"center", justifyContent:"space-between"
          }}>
            <span style={{color:C.muted,fontSize:12.5}}>
              {pg*PER+1}–{Math.min((pg+1)*PER,total)} {t.of} {total} {t.rows}
            </span>
            <div style={{display:"flex",gap:4}}>
              <button onClick={()=>setPg(p=>Math.max(0,p-1))} disabled={pg===0} style={{
                padding:"6px 11px", background:C.surface2, border:`1px solid ${C.border}`,
                borderRadius:6, color:C.text, cursor: pg===0?"not-allowed":"pointer",
                opacity: pg===0?.4:1, fontFamily:"inherit", fontSize:13, lineHeight:0
              }}>
                {isAr?<ChevronRight size={14}/>:<ChevronLeft size={14}/>}
              </button>
              {Array.from({length:Math.min(5,pages)},(_,i)=>{
                const p = Math.max(0,Math.min(pg-2,pages-5))+i
                const active = p===pg
                return (
                  <button key={p} onClick={()=>setPg(p)} style={{
                    padding:"5px 10px", background: active?C.gold:C.surface2,
                    border:`1px solid ${active?C.gold:C.border}`,
                    borderRadius:6, color: active?"#0a0b10":C.text,
                    cursor:"pointer", fontFamily:"inherit", fontSize:13, fontWeight: active?700:400
                  }}>{p+1}</button>
                )
              })}
              <button onClick={()=>setPg(p=>Math.min(pages-1,p+1))} disabled={pg===pages-1} style={{
                padding:"6px 11px", background:C.surface2, border:`1px solid ${C.border}`,
                borderRadius:6, color:C.text, cursor: pg===pages-1?"not-allowed":"pointer",
                opacity: pg===pages-1?.4:1, fontFamily:"inherit", fontSize:13, lineHeight:0
              }}>
                {isAr?<ChevronLeft size={14}/>:<ChevronRight size={14}/>}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════
// COMING SOON
// ═══════════════════════════════════════════════════════════
function Soon({ lang, emoji, label }) {
  const t = T[lang]
  return (
    <div style={{
      flex:1, display:"flex", flexDirection:"column",
      alignItems:"center", justifyContent:"center",
      gap:14, color:C.muted, padding:40, textAlign:"center"
    }}>
      <div style={{fontSize:56,lineHeight:1}}>{emoji}</div>
      <h2 style={{color:C.text,margin:0,fontSize:22,fontWeight:700}}>{t.comingSoon}</h2>
      <p style={{margin:0,fontSize:14,maxWidth:280}}>{t.comingDesc}</p>
      <div style={{
        marginTop:8, background:C.goldBg, border:`1px solid ${C.gold}30`,
        borderRadius:20, padding:"6px 18px", color:C.gold, fontSize:12.5, fontWeight:600
      }}>{label}</div>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════
// MAIN LAYOUT
// ═══════════════════════════════════════════════════════════
function Layout({ lang, setLang }) {
  const [page, setPage] = useState("dashboard")
  const [collapsed, setCollapsed] = useState(false)
  const t = T[lang], isAr = lang==="ar"

  const titles = {
    dashboard:t.dashboard, hr:t.hr, branches:t.branches,
    customers:t.customers, b2b:t.b2b, crm:t.crm,
    reports:t.reports, settings:t.settings
  }

  const body = () => {
    if (page==="dashboard") return <Dashboard lang={lang}/>
    if (page==="hr")        return <HR lang={lang}/>
    if (page==="branches")  return <Soon lang={lang} emoji="🏪" label={t.branches}/>
    if (page==="customers") return <Soon lang={lang} emoji="🛒" label={t.customers}/>
    if (page==="b2b")       return <Soon lang={lang} emoji="🤝" label={t.b2b}/>
    if (page==="crm")       return <Soon lang={lang} emoji="💬" label={t.crm}/>
    if (page==="reports")   return <Soon lang={lang} emoji="📊" label={t.reports}/>
    if (page==="settings")  return <Soon lang={lang} emoji="⚙️" label={t.settings}/>
  }

  return (
    <div style={{
      display:"flex", height:"100vh", overflow:"hidden",
      background:C.bg, color:C.text,
      direction: isAr?"rtl":"ltr",
      flexDirection: isAr?"row-reverse":"row",
      fontFamily: isAr?"Tajawal,sans-serif":"DM Sans,sans-serif"
    }}>
      <Sidebar lang={lang} page={page} setPage={setPage} collapsed={collapsed}/>
      <div style={{flex:1,display:"flex",flexDirection:"column",overflow:"hidden",minWidth:0}}>
        <Header lang={lang} setLang={setLang} collapsed={collapsed}
                setCollapsed={setCollapsed} title={titles[page]}/>
        <main style={{flex:1,overflowY:"auto"}}>{body()}</main>
      </div>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════
// ROOT
// ═══════════════════════════════════════════════════════════
export default function App() {
  const [lang, setLang] = useState("ar")

  useEffect(() => {
    const l = document.createElement("link")
    l.rel = "stylesheet"
    l.href = "https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700&family=DM+Sans:wght@300;400;500;600;700&display=swap"
    document.head.appendChild(l)
  }, [])

  return (
    <AuthProvider>
      <Router lang={lang} setLang={setLang}/>
    </AuthProvider>
  )
}

function Router({ lang, setLang }) {
  const { session } = useAuth()
  return session
    ? <Layout lang={lang} setLang={setLang}/>
    : <Login  lang={lang} setLang={setLang}/>
}
